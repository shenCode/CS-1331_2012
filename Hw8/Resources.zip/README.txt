Last Image from: http://usqedu.wordpress.com/tag/success/

Laptop from: Lenovo website

To complete:

Go to door 2, get the note. Then click on it to reveal the password.
Go back to the beginning scene then enter door 1.
Get the laptop, then click on the laptop to enter the password to win the game.